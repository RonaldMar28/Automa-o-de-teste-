import pyautogui
import time

#time.sleep(5)
#print(pyautogui.position()) #Mouse atual x e y
#print(pyautogui.size()) # Resolução atual da tela largula e altura

time.sleep(2)
pyautogui.hotkey('win', 'e')

pyautogui.click(x=142, y=587, duration=3)
pyautogui.click(x=460, y=449, duration=1, clicks=3)  
pyautogui.click(x=382, y=612, duration=1, clicks=3)
pyautogui.click(x=515, y=383, duration=1, clicks=3)
pyautogui.click(x=622, y=508, duration=2, clicks=1)   
pyautogui.click(x=361, y=173, duration=2, clicks=1)   
pyautogui.click(x=300, y=213, duration=2, clicks=1)  
pyautogui.click(x=54, y=246, duration=2, clicks=1)  
pyautogui.click(x=373, y=427, duration=2, clicks=1)  
pyautogui.click(x=176, y=257, duration=2, clicks=1)   
pyautogui.click(x=480, y=604, duration=2, clicks=1)

pyautogui.typewrite('reboot10')

pyautogui.click(x=705, y=709, duration=2, clicks=1) #salvar txt.
pyautogui.click(x=509, y=825, duration=2, clicks=1) # Iniciar teste.